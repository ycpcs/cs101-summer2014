#include "Console.h"

// TODO: define constants

#define BRICKS_PER_ROW    10
#define NUM_ROWS          6

// TODO: add other struct types (e.g., struct Paddle, struct Brick, etc.)

struct Scene {
	// TODO: add fields
};

#define ANIMATION_DELAY 75

void init_scene(struct Scene *s);
void render_scene(struct Scene *s);
bool update_scene(struct Scene *s, int key);

int main(void)
{
	struct Scene the_scene;

	init_scene(&the_scene);

	bool keep_going = true;
	while (keep_going) {
		cons_clear_screen();
		render_scene(&the_scene);
		cons_update();

		int key = cons_get_keypress();
		keep_going = update_scene(&the_scene, key);

		cons_sleep_ms(ANIMATION_DELAY);
	}

	return 0;
}

void init_scene(struct Scene *s)
{
	// TODO: initialize the Scene
}

void render_scene(struct Scene *s)
{
	// TODO: render the Scene
}

bool update_scene(struct Scene *s, int key)
{
	// TODO: update the scene

	return true; // indicates that the game should continue
}
