#include <stdio.h>
#include <math.h>

// Numbers of rows and columns in the temperature grid
#define HEIGHT 10
#define WIDTH 10

void init_temp_array(double temp[HEIGHT][WIDTH], double top, double right, double bottom, double left);
void print_temperatures(double temp[HEIGHT][WIDTH]);
double avg_of_neighbors(double temp[HEIGHT][WIDTH], int row, int col);

int main(void) {
	// TODO: declare array and other variables

	// TODO: get top/right/bottom/left temperatures from user

	// TODO: call init_temp_array to initialize array

	// TODO: call print_temperatures to print values in array

	// TODO: call avg_of_neighbors and print its output

	return 0;
}

// TODO: define the functions
