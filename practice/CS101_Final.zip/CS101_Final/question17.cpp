#include <stdio.h>

#define MAXVALS 100

// TODO: add prototype for find_min function

///////////////////////////////////////////////////////////
// IMPORTANT: do not modify the main function in any way
///////////////////////////////////////////////////////////
int main(void) {
	int arr[MAXVALS];
	int num_vals = 0;
	int keep_going = 1;

	while (keep_going == 1) {
		int val;
		scanf("%i", &val);
		if (val >= 0) {
			arr[num_vals] = val;
			num_vals++;
		} else {
			keep_going = 0;
		}
	}

	int min;

	min = find_min(arr, num_vals);

	printf("Minimum is: %i\n", min);
	return 0;
}

// TODO: add definition for find_min function

