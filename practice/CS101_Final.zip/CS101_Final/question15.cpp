#include <stdio.h>


// TODO: add prototype for Power function

/////////////////////////////////////////////////////////////
// IMPORTANT: Do not modify the main function in any way
/////////////////////////////////////////////////////////////
int main(void) {
	double x;
	int n;
	double result = 0.0;

	printf("Enter x: ");
	scanf("%lf", &x);
	printf("Enter n: ");
	scanf("%i", &n);

	result = Power(x, n);

	printf("Result is %lf\n", result);

	return 0;
}

// TODO: add definition for Power function

