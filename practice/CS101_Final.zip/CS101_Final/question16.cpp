#include <stdio.h>

int main(void) {
	int size;

	printf("Size: ");
	scanf("%i", &size);

	if (size <= 0 || (size % 2) != 1) {
		printf("Size must be positive and odd\n");
		return 1;
	}

	// TODO: Add your code here
	
	return 0;
}
