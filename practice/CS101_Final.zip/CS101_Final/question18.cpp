#include <stdio.h>

#define MAXCARDS 10

struct Card {
	int rank;
	char suit;
};

bool is_flush(const struct Card hand[], int numcards);
bool is_straight(const struct Card hand[], int numcards);

////////////////////////////////////////////////////////////
// IMPORTANT: Do not modify the main function in any way
////////////////////////////////////////////////////////////
int main(void) {
	struct Card myHand[MAXCARDS];
	int count = 0;

	printf("Enter cards: ");
	bool keep_going = true;
	while (keep_going) {
		int rank;
		char suit;
		scanf("%i", &rank);
		if (rank < 0) {
			keep_going = false;
		} else {
			scanf(" %c", &suit);
			myHand[count].rank = rank;
			myHand[count].suit = suit;
			count++;
		}
	}

	bool is_flush_result = is_flush(myHand, count);
	bool is_straight_result = is_straight(myHand, count);

	if (is_flush_result) {
		printf("is_flush returned true\n");
	} else {
		printf("is_flush returned false\n");
	}

	if (is_straight_result) {
		printf("is_straight returned true\n");
	} else {
		printf("is_straight returned false\n");
	}

	return false;
}

bool is_flush(const struct Card hand[], int numcards) {
	// TODO: add your code here
}

bool is_straight(const struct Card hand[], int numcards) {
	// TODO: add your code here
}
