#include <stdio.h>

struct Point {
	double x, y;
};

// Prototype for the find_quadrant function
int find_quadrant(struct Point p);

// IMPORTANT: do not change the main function in any way
int main(void) {
	struct Point p;

	printf("Enter x and y: ");
	scanf("%lf %lf", &p.x, &p.y);

	int result = find_quadrant(p);
	printf("find_quadrant returned %i\n", result);
	return 0;
}

// TODO: define the find_quadrant function
