#include <stdio.h>

#define MAX 500

// Prototype for the first_occurrence function
int first_occurrence(double arr[], int num_elts, double sval);

// IMPORTANT: do not change the main function in any way
int main(void) {
	double a[MAX];
	int num;
	double search;

	printf("How many values? ");
	scanf("%i", &num);
	printf("Enter the values: ");
	for (int i = 0; i < num; i++) {
		scanf("%lf", &a[i]);
	}
	printf("What search value? ");
	scanf("%lf", &search);

	int result = first_occurrence(a, num, search);
	printf("first_occurrence returned %i\n", result);

	return 0;
}

// TODO: define the first_occurrence function
